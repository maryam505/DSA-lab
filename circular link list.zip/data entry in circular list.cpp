#include <iostream>
#include <string>
using namespace std;

struct Node {
    string name;
    Node* next;
};

void display(Node* head) {
    if (head == NULL) {
        cout << "No employees in the list!" << endl;
        return;
    }
    Node* temp = head;
    cout << "Employee List: ";
    do {
        cout << temp->name << " ";
        temp = temp->next;
    } while (temp != head);
    cout << endl;
}

void addEmployee(Node*& head, string empName) {
    Node* newNode = new Node();
    newNode->name = empName;

    if (head == NULL) {
        newNode->next = newNode;
        head = newNode;
        cout << empName << " added successfully." << endl;
        return;
    }

    Node* temp = head;
    while (temp->next != head)
        temp = temp->next;

    temp->next = newNode;
    newNode->next = head;
    cout << empName << " added successfully." << endl;
}

void deleteEmployee(Node*& head, string empName) {
    if (head == NULL) {
        cout << "List is empty!" << endl;
        return;
    }

    Node* curr = head;
    Node* prev = NULL;

    if (head->next == head && head->name == empName) {
        delete head;
        head = NULL;
        cout << empName << " deleted successfully." << endl;
        return;
    }

    if (head->name == empName) {
        Node* temp = head;
        while (temp->next != head)
            temp = temp->next;
        temp->next = head->next;
        Node* del = head;
        head = head->next;
        delete del;
        cout << empName << " deleted successfully." << endl;
        return;
    }

    prev = head;
    curr = head->next;

    while (curr != head) {
        if (curr->name == empName) {
            prev->next = curr->next;
            delete curr;
            cout << empName << " deleted successfully." << endl;
            return;
        }
        prev = curr;
        curr = curr->next;
    }

    cout << empName << " not found!" << endl;
}

void searchEmployee(Node* head, string empName) {
    if (head == NULL) {
        cout << "List is empty!" << endl;
        return;
    }
    Node* temp = head;
    do {
        if (temp->name == empName) {
            cout << empName << " found successfully." << endl;
            return;
        }
        temp = temp->next;
    } while (temp != head);
    cout << empName << " not found!" << endl;
}

void updateEmployee(Node* head, string oldName, string newName) {
    if (head == NULL) {
        cout << "List is empty!" << endl;
        return;
    }
    Node* temp = head;
    do {
        if (temp->name == oldName) {
            temp->name = newName;
            cout << "Updated successfully." << endl;
            return;
        }
        temp = temp->next;
    } while (temp != head);
    cout << oldName << " not found!" << endl;
}

int main() {
    Node* head = NULL;
    int choice;
    string name, oldName, newName;

    do {
        cout << "\n--- Employee Data Management ---" << endl;
        cout << "1. Add Employee" << endl;
        cout << "2. Delete Employee" << endl;
        cout << "3. Search Employee" << endl;
        cout << "4. Update Employee" << endl;
        cout << "5. Display All Employees" << endl;
        cout << "6. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter employee name: ";
                cin >> name;
                addEmployee(head, name);
                break;
            case 2:
                cout << "Enter employee name to delete: ";
                cin >> name;
                deleteEmployee(head, name);
                break;
            case 3:
                cout << "Enter employee name to search: ";
                cin >> name;
                searchEmployee(head, name);
                break;
            case 4:
                cout << "Enter old name: ";
                cin >> oldName;
                cout << "Enter new name: ";
                cin >> newName;
                updateEmployee(head, oldName, newName);
                break;
            case 5:
                display(head);
                break;
            case 6:
                cout << "Exiting program..." << endl;
                break;
            default:
                cout << "Invalid choice!" << endl;
        }
    } while (choice != 6);

    return 0;
}

