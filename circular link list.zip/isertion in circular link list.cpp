#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

void display(Node* head) {
    if (head == NULL) {
        cout << "List is empty!" << endl;
        return;
    }
    Node* temp = head;
    cout << "Circular Linked List: ";
    do {
        cout << temp->data << " ";
        temp = temp->next;
    } while (temp != head);
    cout << endl;
}

void insertBefore(Node*& head, int value) {
    Node* newNode = new Node();
    newNode->data = value;

    if (head == NULL) {
        newNode->next = newNode;
        head = newNode;
        return;
    }

    Node* temp = head;
    while (temp->next != head)
        temp = temp->next;

    newNode->next = head;
    temp->next = newNode;
    head = newNode;
}

void insertAfter(Node*& head, int value) {
    Node* newNode = new Node();
    newNode->data = value;

    if (head == NULL) {
        newNode->next = newNode;
        head = newNode;
        return;
    }

    Node* temp = head;
    while (temp->next != head)
        temp = temp->next;

    temp->next = newNode;
    newNode->next = head;
}

void deleteNode(Node*& head, int key) {
    if (head == NULL) {
        cout << "List is empty!" << endl;
        return;
    }

    Node *curr = head, *prev = NULL;

    if (head->next == head && head->data == key) {
        delete head;
        head = NULL;
        cout << "Node " << key << " deleted." << endl;
        return;
    }

    if (head->data == key) {
        Node* temp = head;
        while (temp->next != head)
            temp = temp->next;

        temp->next = head->next;
        Node* del = head;
        head = head->next;
        delete del;
        cout << "Node " << key << " deleted." << endl;
        return;
    }

    prev = head;
    curr = head->next;

    while (curr != head) {
        if (curr->data == key) {
            prev->next = curr->next;
            delete curr;
            cout << "Node " << key << " deleted." << endl;
            return;
        }
        prev = curr;
        curr = curr->next;
    }

    cout << "Node " << key << " not found!" << endl;
}

int main() {
    Node* head = NULL;

    insertBefore(head, 30);
    insertBefore(head, 20);
    insertBefore(head, 10);
    display(head);

    insertAfter(head, 40);
    insertAfter(head, 50);
    display(head);

    deleteNode(head, 10);
    display(head);

    deleteNode(head, 50);
    display(head);

    deleteNode(head, 30);
    display(head);

    return 0;
}

