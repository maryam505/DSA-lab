#include <iostream>
#include <string>
using namespace std;

class Book {
private:
    string bookId;
    string bookName;
    double bookPrice;
    string bookAuthor;
    string bookISBN;

public:
    Book() {}
    Book(string id, string name, double price, string author, string isbn) {
        bookId = id;
        bookName = name;
        bookPrice = price;
        bookAuthor = author;
        bookISBN = isbn;
    }

    string getBookId() { return bookId; }
    string getBookName() { return bookName; }
    double getBookPrice() { return bookPrice; }
    string getBookAuthor() { return bookAuthor; }
    string getBookISBN() { return bookISBN; }

    void setBookId(string id) { bookId = id; }
    void setBookName(string name) { bookName = name; }
    void setBookPrice(double price) { bookPrice = price; }
    void setBookAuthor(string author) { bookAuthor = author; }
    void setBookISBN(string isbn) { bookISBN = isbn; }

    void printBookDetails() {
        cout << "ID: " << bookId
             << ", Name: " << bookName
             << ", Price: " << bookPrice
             << ", Author: " << bookAuthor
             << ", ISBN: " << bookISBN << endl;
    }
};

class Node {
private:
    Book book;
    Node* next;
    Node* prev;

public:
    Node() { next = prev = NULL; }
    Node(Book b) { book = b; next = prev = NULL; }

    Book getBook() { return book; }
    Node* getNext() { return next; }
    Node* getPrev() { return prev; }

    void setBook(Book b) { book = b; }
    void setNext(Node* n) { next = n; }
    void setPrev(Node* p) { prev = p; }
};

class BookList {
private:
    Node* head;

public:
    BookList() { head = NULL; }

    void addBook(string id, string name, double price, string author, string isbn) {
        Book newBook(id, name, price, author, isbn);
        Node* newNode = new Node(newBook);

        if (head == NULL) {
            head = newNode;
            head->setNext(head);
            head->setPrev(head);
            cout << "Book " << id << " added successfully." << endl;
            return;
        }

        Node* last = head->getPrev();
        last->setNext(newNode);
        newNode->setPrev(last);
        newNode->setNext(head);
        head->setPrev(newNode);

        cout << "Book " << id << " added successfully." << endl;
    }

    void removeBook(string id) {
        if (head == NULL) {
            cout << "No books in list!" << endl;
            return;
        }

        Node* current = head;
        Node* prev = NULL;

        do {
            if (current->getBook().getBookId() == id) {
                if (current->getNext() == head && current == head) {
                    head = NULL;
                } else if (current == head) {
                    Node* last = head->getPrev();
                    head = head->getNext();
                    head->setPrev(last);
                    last->setNext(head);
                } else {
                    Node* p = current->getPrev();
                    Node* n = current->getNext();
                    p->setNext(n);
                    n->setPrev(p);
                }
                delete current;
                cout << "Book " << id << " removed successfully." << endl;
                return;
            }
            current = current->getNext();
        } while (current != head);

        cout << "Book " << id << " not found!" << endl;
    }

    void updateBook(string id, string name, double price, string author, string isbn) {
        if (head == NULL) {
            cout << "No books in list!" << endl;
            return;
        }

        Node* temp = head;
        do {
            if (temp->getBook().getBookId() == id) {
                Book updated(id, name, price, author, isbn);
                temp->setBook(updated);
                cout << "Book " << id << " updated successfully." << endl;
                return;
            }
            temp = temp->getNext();
        } while (temp != head);

        cout << "Book " << id << " not found!" << endl;
    }

    void printBooks() {
        if (head == NULL) {
            cout << "No books to display!" << endl;
            return;
        }
        Node* temp = head;
        cout << "\n--- Book List ---" << endl;
        do {
            temp->getBook().printBookDetails();
            temp = temp->getNext();
        } while (temp != head);
    }

    void printBook(string id) {
        if (head == NULL) {
            cout << "No books in list!" << endl;
            return;
        }

        Node* temp = head;
        do {
            if (temp->getBook().getBookId() == id) {
                cout << "\n--- Book Found ---" << endl;
                temp->getBook().printBookDetails();
                return;
            }
            temp = temp->getNext();
        } while (temp != head);

        cout << "Book " << id << " not found!" << endl;
    }
};

int main() {
    BookList list;

    list.addBook("B1", "C++", 500, "Stroustrup", "ISBN101");
    list.addBook("B2", "Java", 450, "Gosling", "ISBN102");
    list.addBook("B3", "Python", 400, "Rossum", "ISBN103");
    list.addBook("B4", "C#", 420, "Anders", "ISBN104");
    list.addBook("B5", "HTML", 300, "BernersLee", "ISBN105");
    list.addBook("B6", "CSS", 350, "Meyer", "ISBN106");
    list.addBook("B7", "JavaScript", 600, "Flanagan", "ISBN107");
    list.addBook("B8", "SQL", 320, "Date", "ISBN108");
    list.addBook("B9", "Kotlin", 550, "JetBrains", "ISBN109");
    list.addBook("B10", "Swift", 480, "Apple", "ISBN110");

    list.printBooks();

    list.removeBook("B3");
    list.removeBook("B50");

    list.printBooks();

    list.updateBook("B2", "Java Updated", 500, "James Gosling", "ISBN202");
    list.printBook("B2");

    return 0;
}

