#include <iostream>
using namespace std;

class Inventory {
private:
    int serialNum;
    int manufactYear;
    int lotNum;

public:
   
    Inventory() {
        serialNum = 0;
        manufactYear = 0;
        lotNum = 0;
    }

    Inventory(int s, int y, int l) {
        serialNum = s;
        manufactYear = y;
        lotNum = l;
    }

    void setSerialNum(int s) { serialNum = s; }
    void setManufactYear(int y) { manufactYear = y; }
    void setLotNum(int l) { lotNum = l; }

    int getSerialNum() { return serialNum; }
    int getManufactYear() { return manufactYear; }
    int getLotNum() { return lotNum; }

    void display() {
        cout << "Serial Number: " << serialNum << endl;
        cout << "Manufacture Year: " << manufactYear << endl;
        cout << "Lot Number: " << lotNum << endl;
    }
};

struct Node {
    Inventory data;
    Node* next;
};

class Stack {
private:
    Node* top;

public:
    Stack() { top = NULL; }

    void push(Inventory inv) {
        Node* newNode = new Node;
        newNode->data = inv;
        newNode->next = top;
        top = newNode;
        cout << "Part added to inventory successfully.\n";
    }

    bool pop() {
        if (isEmpty()) {
            cout << "Inventory is empty! Nothing to remove.\n";
            return false;
        }
        Node* temp = top;
        cout << "\nRemoved part details:\n";
        top->data.display();
        top = top->next;
        delete temp;
        return true;
    }

    bool isEmpty() {
        return top == NULL;
    }

    void displayAll() {
        if (isEmpty()) {
            cout << "No remaining parts in inventory.\n";
            return;
        }

        cout << "\nRemaining Parts in Inventory:\n";
        Node* temp = top;
        while (temp != NULL) {
            temp->data.display();
            cout << "-----------------------\n";
            temp = temp->next;
        }
    }
};

int main() {
    Stack inventoryStack;
    int choice;

    cout << "===== INVENTORY MANAGEMENT SYSTEM =====\n";

    do {
        cout << "\n1. Add a part to inventory";
        cout << "\n2. Remove a part from inventory";
        cout << "\n3. Display all remaining parts";
        cout << "\n4. Exit";
        cout << "\nEnter your choice: ";
        cin >> choice;

        if (choice == 1) {
            int s, y, l;
            cout << "\nEnter Serial Number: ";
            cin >> s;
            cout << "Enter Manufacture Year: ";
            cin >> y;
            cout << "Enter Lot Number: ";
            cin >> l;

            Inventory inv(s, y, l);
            inventoryStack.push(inv);
        }
        else if (choice == 2) {
            inventoryStack.pop();
        }
        else if (choice == 3) {
            inventoryStack.displayAll();
        }
        else if (choice == 4) {
            cout << "\nExiting program...\n";
            break;
        }
        else {
            cout << "Invalid choice! Try again.\n";
        }

    } while (choice != 4);

    cout << "\nFinal Inventory Status:\n";
    inventoryStack.displayAll();

    return 0;
}

