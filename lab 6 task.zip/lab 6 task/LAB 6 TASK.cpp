#include <iostream>
#include <string>
using namespace std;

struct Node {
    string title;
    float price;
    int edition;
    int pages;
    Node* next;
};

Node* top = NULL;
// Push function
void push(string title, float price, int edition, int pages) {
    Node* newNode = new Node();
    newNode->title = title;
    newNode->price = price;
    newNode->edition = edition;
    newNode->pages = pages;
    newNode->next = top;
    top = newNode;
    cout << "Book pushed onto stack.\n";
}
// Pop function
void pop() {
    if (top == NULL) {
        cout << "Stack is empty. Cannot pop.\n";
        return;
    }
    Node* temp = top;
    top = top->next;
    delete temp;
    cout << "Book popped from stack.\n";
}
// Peek (top element)
void peek() {
    if (top == NULL) {
        cout << "Stack is empty.\n";
        return;
    }
    cout << "\n Top book details:\n";
    cout << "Title: " << top->title
         << ", Price: " << top->price
         << ", Edition: " << top->edition
         << ", Pages: " << top->pages << endl;
}
// Display all books
void display() {
    if (top == NULL) {
        cout << "Stack is empty.\n";
        return;
    }
    cout << "\nBooks currently in stack:\n";
    Node* temp = top;
    while (temp != NULL) {
        cout << "Title: " << temp->title
             << ", Price: " << temp->price
             << ", Edition: " << temp->edition
             << ", Pages: " << temp->pages << endl;
        temp = temp->next;
    }
}

int main() {
    // Step 1: Push 5 books
    push("C++ Programming", 900, 5, 1200);
    push("Java Basics", 750, 3, 800);
    push("Python Guide", 850, 4, 950);
    push("Data Structures", 1000, 2, 600);
    push("Algorithms", 1200, 6, 700);

    cout << "--- Top Element ---";
    peek();

    cout << "Pop 2 Books";
    pop();
    pop();

    cout << "--- Display Remaining Books ----";
    display();

    return 0;
}

