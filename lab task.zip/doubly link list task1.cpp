#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* prev;
    Node* next;
};

// Function to display list
void display(Node* head) {
    Node* temp = head;
    cout << "List: ";
    while (temp != NULL) {
        cout << temp->data << " <-> ";
        temp = temp->next;
    }
    cout << "NULL" << endl;
}

// Function to add node at beginning
void addAtBeginning(Node*& head, int value) {
    Node* newNode = new Node();
    newNode->data = value;
    newNode->prev = NULL;
    newNode->next = head;

    if (head != NULL) {
        head->prev = newNode;
    }
    head = newNode;
    cout << "Inserted " << value << " in node.\n";
}

// Function to add node after a given value
void addAfterValue(Node*& head, int pos, int value) {
    Node* temp = head;
    while (temp != NULL && temp->data != pos) {
        temp = temp->next;
    }

    if (temp == NULL) {
        cout << "Value " << pos << " not found!\n";
        return;
    }

    Node* newNode = new Node();
    newNode->data = value;
    newNode->next = temp->next;
    newNode->prev = temp;

    if (temp->next != NULL) {
        temp->next->prev = newNode;
    }
    temp->next = newNode;

    cout << "Inserted " << value << " after " << pos << ".\n";
}

// Function to delete node at beginning
void deleteAtBeginning(Node*& head) {
    if (head == NULL) {
        cout << "List is empty!\n";
        return;
    }

    Node* temp = head;
    head = head->next;

    if (head != NULL) {
        head->prev = NULL;
    }

    cout << "Deleted " << temp->data << " from beginning.\n";
    delete temp;
}

// Function to delete node after a given value
void deleteAfterValue(Node*& head, int pos) {
    Node* temp = head;
    while (temp != NULL && temp->data != pos) {
        temp = temp->next;
    }

    if (temp == NULL || temp->next == NULL) {
        cout << "No node exists after " << pos << "!\n";
        return;
    }

    Node* del = temp->next;
    temp->next = del->next;

    if (del->next != NULL) {
        del->next->prev = temp;
    }

    cout << "Deleted " << del->data << " after " << pos << ".\n";
    delete del;
}

int main() {
    Node* head = NULL;
    int n, value;

    cout << "Enter number of nodes: ";
    cin >> n;

    cout << "Enter values: ";
    for (int i = 0; i < n; i++) {
        cin >> value;
        addAtBeginning(head, value); // initially inserting at beginning
    }
    cout << "\nOriginal List:\n";
     display(head);
    // Add at beginning
    addAtBeginning(head, 100);
    display(head);
    // Add after 45
    addAfterValue(head, 45, 200);
    display(head);
    // Delete at beginning
    deleteAtBeginning(head);
    display(head);
    // Delete after 45
    deleteAfterValue(head, 45);
    display(head);

    return 0;
}

