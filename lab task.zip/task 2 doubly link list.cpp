#include <iostream>
using namespace std;

struct Node {
    int data;       // rainfall amount
    Node* prev;
    Node* next;
};

// Insert at end of doubly linked list
void insertAtEnd(Node*& head, int value) {
    Node* newNode = new Node();
    newNode->data = value;
    newNode->next = NULL;
    newNode->prev = NULL;

    if (head == NULL) {
        head = newNode;
        return;
    }

    Node* temp = head;
    while (temp->next != NULL) {
        temp = temp->next;
    }

    temp->next = newNode;
    newNode->prev = temp;
}

// Display the list
void display(Node* head) {
    Node* temp = head;
    int day = 1;
    while (temp != NULL) {
        cout << "Day " << day << " rainfall: " << temp->data << endl;
        temp = temp->next;
        day++;
    }
}

// Calculate total, average, highest, lowest
void calculate(Node* head) {
    if (head == NULL) {
        cout << "List is empty!" << endl;
        return;
    }

    int total = 0, count = 0;
    int highest = head->data, lowest = head->data;
    int highDay = 1, lowDay = 1;
    int day = 1;

    Node* temp = head;
    while (temp != NULL) {
        total += temp->data;

        if (temp->data > highest) {
            highest = temp->data;
            highDay = day;
        }
        if (temp->data < lowest) {
            lowest = temp->data;
            lowDay = day;
        }

        temp = temp->next;
        count++;
        day++;
    }

    double average = (double) total / count;

    cout << "\n=== Weekly Rainfall Report ===\n";
    cout << "Total rainfall: " << total << endl;
    cout << "Average rainfall: " << average << endl;
    cout << "Highest rainfall: " << highest << " (Day " << highDay << ")\n";
    cout << "Lowest rainfall: " << lowest << " (Day " << lowDay << ")\n";
}

// Show rainfall after 5th node
void rainfallAfterFifth(Node* head) {
    Node* temp = head;
    int count = 1;
    while (temp != NULL && count < 6) {
        temp = temp->next;
        count++;
    }

    if (temp != NULL) {
        cout << "Rainfall of day after 5th node (Day 6): " << temp->data << endl;
    } else {
        cout << "There is no node after the 5th day!" << endl;
    }
}

int main() {
    Node* head = NULL;
    int value;

    cout << "Enter rainfall for 7 days:\n";
    for (int i = 1; i <= 7; i++) {
        do {
            cout << "Day " << i << ": ";
            cin >> value;
            if (value < 0) {
                cout << "Invalid input! Rainfall cannot be negative. Try again.\n";
            }
        } while (value < 0);
        insertAtEnd(head, value);
    }

    cout << "\n--- Entered Rainfall Data ---\n";
    display(head);

    calculate(head);

    rainfallAfterFifth(head);

    return 0;
}

