#include <iostream>
#include <string>
using namespace std;

struct Player {
    string name;
    int score;
    Player* next;
    Player* prev;
};

// Insert new player in sorted order (ascending by score)
void addPlayer(Player*& head, string name, int score) {
    Player* newPlayer = new Player{name, score, NULL, NULL};

    if (head == NULL) { // empty list
        head = newPlayer;
        return;
    }

    Player* temp = head;
    Player* prev = NULL;

    // find insertion point
    while (temp != NULL && temp->score < score) {
        prev = temp;
        temp = temp->next;
    }

    if (prev == NULL) { // insert at beginning
        newPlayer->next = head;
        head->prev = newPlayer;
        head = newPlayer;
    } else {
        newPlayer->next = temp;
        newPlayer->prev = prev;
        prev->next = newPlayer;
        if (temp != NULL) temp->prev = newPlayer;
    }
}

// Delete a player by name
void deletePlayer(Player*& head, string name) {
    if (head == NULL) {
        cout << "List is empty!" << endl;
        return;
    }

    Player* temp = head;
    while (temp != NULL && temp->name != name) {
        temp = temp->next;
    }

    if (temp == NULL) {
        cout << "Player not found!" << endl;
        return;
    }

    if (temp->prev != NULL) {
        temp->prev->next = temp->next;
    } else {
        head = temp->next; // deleting head
    }
    if (temp->next != NULL) {
        temp->next->prev = temp->prev;
    }

    cout << "Deleted player: " << temp->name << endl;
    delete temp;
}

// Display all players
void display(Player* head) {
    if (head == NULL) {
        cout << "No players in the list." << endl;
        return;
    }
    cout << "\nPlayers List (ascending order):\n";
    Player* temp = head;
    while (temp != NULL) {
        cout << temp->name << " - " << temp->score << endl;
        temp = temp->next;
    }
}

// Display lowest score player
void displayLowest(Player* head) {
    if (head == NULL) {
        cout << "No players in the list." << endl;
        return;
    }
    cout << "\nLowest Score Player: " << head->name << " - " << head->score << endl;
}

// Display all players having same score
void displaySameScore(Player* head, int score) {
    Player* temp = head;
    bool found = false;
    cout << "\nPlayers with score " << score << ":\n";
    while (temp != NULL) {
        if (temp->score == score) {
            cout << temp->name << " - " << temp->score << endl;
            found = true;
        }
        temp = temp->next;
    }
    if (!found) cout << "No players with this score." << endl;
}

// Display backward from a given player name
void displayBackward(Player* head, string name) {
    Player* temp = head;
    while (temp != NULL && temp->name != name) {
        temp = temp->next;
    }

    if (temp == NULL) {
        cout << "Player not found!" << endl;
        return;
    }

    cout << "\nBackward list from " << name << ":\n";
    while (temp != NULL) {
        cout << temp->name << " - " << temp->score << endl;
        temp = temp->prev;
    }
}

int main() {
    Player* head = NULL;
    int choice, score;
    string name;

    do {
        cout << "\n--- Golf Tournament Menu ---\n";
        cout << "1. Add New Player\n";
        cout << "2. Delete Player\n";
        cout << "3. Display All Players\n";
        cout << "4. Display Lowest Score Player\n";
        cout << "5. Display Players with Same Score\n";
        cout << "6. Display Backward from a Player\n";
        cout << "0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter player name: ";
                cin >> name;
                cout << "Enter score: ";
                cin >> score;
                addPlayer(head, name, score);
                break;

            case 2:
                cout << "Enter player name to delete: ";
                cin >> name;
                deletePlayer(head, name);
                break;

            case 3:
                display(head);
                break;

            case 4:
                displayLowest(head);
                break;

            case 5:
                cout << "Enter score to search: ";
                cin >> score;
                displaySameScore(head, score);
                break;

            case 6:
                cout << "Enter player name to start backward display: ";
                cin >> name;
                displayBackward(head, name);
                break;

            case 7:
                cout << "Exiting program..." << endl;
                break;

            default:
                cout << "Invalid choice!" << endl;
        }
    } while (choice != 0);

    return 0;
}

